
function main() {

(function () {
   'use strict';

   //your code here


	
}());


}
main();