var express = require('express');
var fs = require("fs");
var _ = require('underscore');
var moment = require('moment');
var request = require('request');
var async = require('async');
var router = express.Router();
var api_key = 'key-62a2788e75a77d7776a25966eb4e9d5f';
var domain = 'mg.getamper.io';
var mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});

/* GET home page. */

router.get('/', function(req, res) {
  res.render('index');
});

router.post('/mailer', function(req, res) {
    console.log(req.body);
    var message_data = req.body;
    var data = {
      from: message_data.name +' <'+message_data.email+'>',
      to: 'info@getamper.io',
      subject: 'getamper.io contact form from ' + message_data.name,
      text: message_data.message
    };
     
    mailgun.messages().send(data, function (error, body) {
      if(error) {
        console.log(error)
        res.status(500).send(error);
      } else {
        res.sendStatus(200);
      }
    });
});


module.exports = router;
